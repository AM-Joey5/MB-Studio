Add your studio photography here (JPG/WEBP, optimized for web).
Expected filenames are referenced throughout the HTML — e.g. studio-room-a.jpg, gallery-01.jpg, team-01.jpg, client-01.jpg, og-cover.jpg.
