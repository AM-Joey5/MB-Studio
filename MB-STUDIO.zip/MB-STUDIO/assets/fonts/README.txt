Add any self-hosted font files here (e.g. .woff2). This template loads Fraunces, Inter and Space Mono from Google Fonts by default, so this folder is optional.
