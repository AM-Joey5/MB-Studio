Add SVG or PNG icons here if you extend beyond the inline text/glyph icons used in this template.
