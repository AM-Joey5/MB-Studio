Add video files here, e.g. session-reel.mp4, used in gallery.html.
